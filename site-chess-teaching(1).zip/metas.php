<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MXMQBTV');</script>
<!-- End Google Tag Manager -->

<meta name=keywords content='�checs,enseignement,p�dagogie,fran�ais,francophone,entrainement,chess,teaching,training,coaching,young,ratings,schach,�checs'>
<meta name=description content="Enseignement du Jeu d'Echecs.">
<meta HTTP-EQUIV='cache-control' CONTENT='no-store'>
<meta HTTP-EQUIV='Expires' CONTENT='0'>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>
<link rel="stylesheet" href="http://www.chess-teaching.com/ct.css">
