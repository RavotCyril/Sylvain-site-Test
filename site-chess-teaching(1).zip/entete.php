<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MXMQBTV"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<table cellpadding=1 cellspacing=0 class="bandeau" align="center">
<tr>
<td align=center valign=top>
<div align=center>
<a href="http://www.chess-teaching.com/" style="text-decoration: none;">
<b><font size="6" color="black">Chess Teaching</font></b><br>
<b><font size="5" color="black">Enseignement du Jeu d��checs</font></b>
</a>
</div>
</td>
</tr>
</table>
