<html><head>
<title>Chess Teaching - Enseignement du Jeu d'Echecs - Streamings en fran�ais</title>
<?php
include('../metas.php');
?>
</head>
<body topmargin="0" leftmargin="0" rightmargin="0">

<?php
include('../entete.php');
?>

<!-- Table de la page enti�re en dessous du bandeau -->
<table class="tablegenerale" align="center" border="0">
<tr><td>

<div align=center>
<font size=5>Streamings en fran�ais</font>
</div>
<br>

<b>HISTORIQUE</b><br><br>
<div style="text-align: justify;">
L'histoire des streamings (live sur internet) en fran�ais commence avec CanalWeb qui propose l'�mission DiagonaleTV. Le premier stream d'un Championnat de France d'�checs fut r�alis� par DiagonaleTV/CanalWeb en 2000 � Vichy. Dans la foul�e c'est le championnat du monde 2000 Kasparov-Kramnik, avec des commentaires en direct par St�phane Laborde, producteur/animateur de DiagonaleTV, et le GM Eloi Relange. C'est un grand succ�s sur Internet (succ�s au sens g�n�ral, pas au sens �chiqu�en !). Il y aura quelques autres streamings, notamment aux Grands Prix de Bordeaux, organis�s par St�phane Laborde, et surtout l'enregistrement de nombreux cours d'�checs en vid�o, qui ont encore une grande cote de popularit� en 2017 (on peut en trouver et en acqu�rir sur Imin�o). DiagonaleTV est la seule �mission qui �tait diffus�e sur CanalWeb et qui existe encore en 2017.
<br><br>
Quelle est l'histoire des streamings sur internet en fran�ais apr�s cela ? Pour le moins creuse, alors m�me que les outils internet permettant de le faire se multiplient et se d�mocratisent. Il y a un streaming en fran�ais lors du tr�s beau <a href="https://www.europe-echecs.com/art/memorial-alekhine-memorial-alekhine-ronde-1-4877.html" target="_blank">M�morial Alekhine 2013</a> organis� en avril � Paris et St-P�tersbourg, comment� par le GM Yannick Pelletier et le MI Jean-Baptiste Mullon. On peut aussi noter un streaming durant le troph�e Karpov au Cap d'Agde 2013, en partenariat avec Europe Echecs, comment� par Marc Quenehen et le MF Sylvain Ravot. (il y avait des commentaires lors des pr�c�dentes �ditions du Cap, �taient-ils en direct sur internet �galement ?) On retrouve Marc et Sylvain aux commentaires des championnats du monde Carlsen-Anand 2013 et 2014, gr�ce � un partenariat Europe Echecs et eGG-one school, avec des �missions en direct le soir des parties, en compagnie de GM/MI invit�s (Andre� Sokolov, Romain Edouard, Christian Bauer, Marie Sebag, Bachar Kouatly, Jean H�bert). Sur le m�me principe il y aura Zurich 2014, le tournoi des <a href="http://chess.egg-one.com/masterclass/home/masterclass_id/70142" target="_blank">candidats 2014</a> et plus tard le tournoi des candidats 2016, par exemple.
<br><br>
On peut indiquer ici que des streamings en fran�ais ont �t� organis�s par Chessbase via Playchess durant les tr�s grands �v�nements, comme les championnats du monde.
<br><br>
Au niveau des �v�n�ments FFE, on en recense un au championnat de France adultes de Nancy 2013 via la "nouvelle" �quipe FFE, avec une premi�re tentative (� v�rifier ?) sur cet �v�nement. L'exp�rience se poursuit � N�mes 2014, non sans certaines difficult�s techniques � ajuster, mais avec les joueurs qui peuvent venir analyser leur partie en direct pour les internautes. Le GM Eric Pri� figure parmi les commentateurs 2013 et 2014. L'exp�rience se poursuit en 2015 sur le Top Jeunes et sur le Top 12, avant de d�boucher finalement � un premier �v�nement abouti au championnat de France adultes St-Quentin 2015, o� 2 webcams font leur apparition dans la salle de jeu sur 2 parties des Nationaux, St�phane Laborde venant fortement renforcer le staff, en particulier en ce qui concerne la technique, qu'il g�rera avec Sylvain Ravot, mais aussi aux commentaires. L'ann�e 2016 est dans la continuit� de cette progression et le staff FFE peut faire appel en plus � K�vin Bordi, d�j� habitu� depuis plus d'un an � faire des streamings sur sa cha�ne Blitzstream. DiagonaleTV d�veloppe un applet, une version adapt�e de pgn4web, logiciel libre dont les auteurs sont sp�cifi�s dans la licence de chaque module. Ce nouvel applet est test� � l'occasion du festival de Nancy 2016, ainsi que les commentaires � distance (les commentateurs ne sont pas sur place). Cet applet est utilis� lors des championnats de France Jeunes de Gonfreville 2016, o� Vincent Vallet apporte un plus avec une cam�ra 100% mobile dans la salle (et hors de la salle). Nouveaux commentaires sur le Top Jeunes (K�vin Bordi, Sylvain Ravot, GM Fabien Libiszewski), le Top 12 (K�vin, Sylvain accompagn�s des GM Yannick Gozzoli, GM Manuel Apicella et GM Adrien Demuth) et 1/2 finales & finale Coupe de France et Top 12 f�minin. Et bien s�r le championnat de France adultes Agen 2016. Cela se poursuit en 2017 mais pas de mani�re aussi exhaustive. St�phane Laborde est seul � la technique et aux commentaires du festival rapide et blitz Nancy 2017, tout comme lors du championnat de France rapide f�minin � Vilandry. La FFE diffuse un live comment� durant les championnats de France Jeunes Belfort 2017 et le Top 12 Chartres 2017, ce dernier en partenariat avec la Web TV locale (commentateurs St�phane et GM Namig Guliyev).
<br><br>
Parall�lement, les streams "purement internet" (c'est-�-dire r�alis�s depuis chez soi plut�t que depuis la salle de tournoi) se d�veloppent. A l'image du gaming, chacun peut cr�er sa cha�ne et streamer. La cha�ne de K�vin Bordi, Blitzstream, en fait l'une de ses activit�s r�guli�res, notamment via un partenariat avec le site chess.com. Certains streams sont sur la cha�ne twitch de chess.com, par exemple les spectaculaires death matchs (blitz et bullet durant 3 heures) entre les meilleurs joueurs du monde (Carlsen remporte la finale 2016 contre Nakamura). Le fort GM Vlad Tkachiev appara�t plusieurs fois. En septembre 2016, K�vin et Sylvain commentent en direct les matchs de l'�quipe de France aux Olympiades 2016. Depuis fin 2016 on retrouve aussi le GM Fabien Libiszewski, qui rejoint le staff Blitzstream. A noter au passage que Fabien avait comment� la Sinquefield Cup 2016 pour chess24, en compagnie de Fiona Steil-Antoni.
<br><br>
Terminons ce petit historique par la retransmission du Grand Chess Tour Paris, en 2016 et 2017. L'�v�nement a de gros moyens et r�alise un streaming de qualit�, sur DailyMotion. Les commentateurs sont le MI Jean-Baptiste Mullon, le GMI Yannick Pelletier, la MI Almira Skripchenko et la premi�re ann�e le MF Jean-Claude Moingt, ce dernier ayant r�guli�rement comment� d'autres �v�nements, m�me si pas forc�ment en streaming.<br>
Dernier �v�nement en date, la 2�me �tape 2017 du Grand Chess Tour, � Louvain en Belgique. Les organisateurs n'ayant pr�vu aucun commentaire en fran�ais, la cha�ne Blitzstream commente officieusement les 5 jours, avec K�vin Bordi, MF Sylvain Ravot et GM Fabien Libiszewski.
<br><br>
<b>PROCHAINS STREAMINGS EN FRAN�AIS PR�VUS</b><br>
<ul>
<li><a href="http://www.videosechecs.com/speed-chess-championship-carlsen-nakamura-mvl-meilleurs/" target="_blank">Speed Chess Championship</a> Grischuk-Rapport 3 ao�t 2017</li>
<li>GCT Sinquefield Cup rapide et blitz avec le retour de Kasparov (cha�ne Blitzstream, avec Vlad Tkachiev)</li>
<li>Championnat de France adultes <a href="https://agen2017.ffechecs.org/" target="_blank">Agen 2017</a></li>
<li>Speed Chess Championship MVL-Xiong 30 ao�t 2017</li>
<li>Septembre : Coupe du monde 2017 (d�partages) sur la cha�ne <a href="https://www.youtube.com/c/videosechecs" target="_blank">Blitzstream</a></li>
</ul>
<br><br>
<b>Enrichissez cette page :</b><br>
- en compl�tant notre historique<br>
- en nous informant de prochains streams en fran�ais sur des �v�nements<br>
Notre adresse de courriel en bas de page.
<br><br>
<b>QUELQUES R�FLEXIONS SUR LE D�VELOPPEMENT DES STREAMINGS EN FRAN�AIS</b><br>
<br>
<b>Format des tournois</b><br>
La grande majorit� des tournois sont soit des tournois ferm�s (tous les joueurs s'affrontent), soit des opens (mode championnat). Les comp�titions par �quipes se d�roulent aussi la plupart du temps en mode championnat (Top 12, Bundesliga, Olympiades, championnat d'Europe, etc.), � l'exception de la coupe de France et de la phase finale du top 12 f�minin. Ce format championnat n'est pas id�al pour faire vivre un �v�nement, le meilleur �tant bien s�r le <b>format coupe</b>, � �liminations. Le spectateur comprend imm�diatement l'enjeu (le gagnant se qualifie, le perdant est �limin�), et cet enjeu est plus grand, et ce sur chaque partie, ce qui cr�e du suspense et de la dramaturgie. Le jeu en lui m�me est aussi plus d�brid� en moyenne.
<br><br>
<b>Cadence des tournois</b><br>
Evidemment la cadence lente, avec des parties qui durent plusieurs heures, n'est pas la plus propice � une retransmission en direct. Le temps disponible tend � transformer la diffusion en cours d'�checs, et il faut attendre la phase du zeitnot (manque de temps) pour voir le jeu s'acc�l�rer et devenir plus incertain. Les meilleures cadences pour des live sont les <b>rapides et les blitz</b>. Cela va vite, le jeu est plus d�brid�.<br>
Si on regarde le Grand Chess Tour, qui est cens� �tre une r�f�rence, ils ont progress� en augmentant le nombre d'�tapes en rapides et blitz, ce qui est positif. Bon, pour l'instant ils n'ont pas compris que le format coupe �tait meilleur, mais ils y viendront peut-�tre. Pourtant ce n'est pas comme si �a n'avait jamais �t� fait, dans les ann�es 90 il y avait de magnifiques tournois PCA, les troph�es Intel. Et en France par exemple dans les ann�es 2000 les Grands Prix de Bordeaux, St�phane Laborde ayant compris �a depuis bien longtemps. Le Speed Chess Championship de chess.com a �t� cr�� depuis le d�part au format coupe, comme la phase finale de la Pro Chess League.
<br><br>
<b>Applets</b><br>
La th�matique des applets est presque sans fin. Il est hautement pr�f�rable d'utiliser une plateforme qui propose les parties en direct. Trois cl�s sont : coordonn�es � l'�cran, possibilit� de bouger les pi�ces pour montrer des variantes, possibilit� de faire des fl�ches et de colorer des cases. A noter que si vous utilisez une plateforme vous d�pendez d'elle, dans ce cas il est pr�f�rable d'�tre en contact avec les responsables et/ou d'�tablir un partenariat (financier ou non). Si vous en avez la possibilit� / les moyens, la meilleure solution consiste � d�velopper votre propre applet. C'est ce qu'a fait DiagonaleTV qui l'a propos� � la FFE en 2016, avec un applet 100% personnalisable et param�trable, qui assure une ind�pendance totale. Il m�rite assur�ment d'�tre d�velopp� davantage mais on en arrive alors � la question du financement du d�veloppement.
<br><br>
<b>Financements</b><br>
C'est une question centrale et qui demeure �pineuse en 2017. Si le tournoi est financ� par un riche m�c�ne, comme la Sinquefield Cup par exemple, vous n'avez aucun probl�me, vous pouvez r�mun�rer une �quipe de 10 personnes pour s'occuper de la retransmission (c'est ce qui est fait pour ce tournoi, pour le championnat des Etats-Unis, pour le Grand Chess Tour). Si votre budget est limit�, c'est tout de suite plus compliqu�. Car on peut estimer le co�t d'une retransmission type Sinquefield � 50 000 euros, fourchette basse. Par exemple la FFE r�alise depuis plusieurs ann�es des streamings avec des moyens tr�s limit�s. Ils n'auraient tout simplement pas eu lieu sans des passionn�s ayant donn� beaucoup de leur temps, citons St�phane Laborde et Sylvain Ravot. Si la FFE consid�re que c'est un poste important pour un �v�nement, elle devra d�dier un budget correspondant � cette importance.<br>
Parlons maintenant des streamings � distance, qui concernent les grands �v�nements internationaux non comment�s officiellement en fran�ais, ou les �v�nements exhibitions comme le Speed Chess Championship. En g�n�ral, clairement, � l'heure actuelle, les organisateurs des tournois n'ayant pas lieu en France ne pr�voient aucun commentaire en fran�ais. Si l'on veut proposer des commentaires au public francophone, qui les finance ? La question est ouverte ! Citons K�vin Bordi qui l'a tr�s souvent fait b�n�volement, par passion, mais o� est le mod�le �conomique des streaming en fran�ais ? Difficile d'imaginer des subventions publiques. Pas �vident d'imaginer un sponsoring priv�, m�me si peut-�tre pas 100% utopique.<br>
Il reste le financement par une plateforme �chiqu�enne. Playchess l'a un peu fait par le pass�, chess24 une fois par hasard, peut-�tre une ou deux autres mais tout ceci reste tr�s ponctuel et ne s'inscrit pas derri�re une volont� et dans la continuit�. Actuellement il y a une plateforme qui a cette volont� de d�velopper les commentaires en fran�ais en direct � moyen et long terme, et qui essaie de s'en donner les moyens, c'est chess.com.<br>
Et enfin il reste le financement participatif. Enfin, oui et non. Car on remarque que les auditeurs sont tr�s contents lorsqu'ils peuvent suivre des commentaires de grands tournois en fran�ais, pourtant, de mani�re paradoxale ils ne sont pas nombreux � �tre pr�ts � contribuer financi�rement � l'existence de ces commentaires. Ce qui fait toujours s'interroger.
<br><br>
<b>QUELQUES AUDIENCES DES STREAMS EN FRANCAIS</b><br>
<br>
<font size=2>
* Speed Chess Championship 2017 (chess.com twitch)<br>
match MVL-Xiong : pointes vers 400
<br><br>
* Championnat de France National Agen 2017<br>
6-7 premiers jours : entre 400 et 500<br>
ronde 9 : entre 700 et 800<br>
d�partages Bacrot-Fressinet : pointe � 1980
<br><br>
* Grand Chess Tour Louvain 2017 non officiel<br>
mercredi-jeudi 150-200
<br><br>
* Grand Chess Tour Paris 2017 officiel<br>
mercredi-jeudi-vendredi 200-300<br>
dimanche finale du tournoi Carlsen-MVL 900 (dailymotion, chiffres sous r�serve)
<br><br>
* Speed Chess Championship 2016 (chess.com twitch)<br>
matchs lambda 200-250<br>
match MVL-Nakamura 500-650<br>
Grischuk comment� par Vlad 500 ou finale Carlsen-Naka 500
<br><br>
* Championnat du monde Carlsen-Karjakin 2016 non officiel (mais suite des analyses quotidiennes le soir durant 3 semaines)<br>
d�partages pour le titre mondial 900-1000
<br><br>
* Championnat de France National Agen 2016<br>
dernier jour 500<br>
autres jours 300 environ
<br><br>
* Sinquefield Cup 2016 (chess24, en horaires d�cal�s + JO (Fab et Fiona))<br>
200-300
<br><br>
* Titled Tuesday chess.com (cha�ne Blitzstream chaque 1er mardi du mois)<br>
170-270 (hiver + ; �t� -)
<br><br>
* Top 12 de 2016<br>
150-200
</font>
<br><br>
Auteur de cette page : <a href="http://www.chess-teaching.com/contributeurs/sylvain_ravot.php">Sylvain Ravot</a>
<br><br>
</span>


<!-- fin table generale -->
</td></tr></table>

<?php
include('../footer.php');
?>


</body>
</html>
