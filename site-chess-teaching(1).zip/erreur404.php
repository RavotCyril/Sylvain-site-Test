<html><head>
<title>Chess Teaching - Enseignement du Jeu d'Echecs</title>
<?php
include('metas.php');
?>
</head>
<body topmargin="0" leftmargin="0" rightmargin="0">

<?php
include('entete.php');
?>

<!-- Table de la page enti�re en dessous du bandeau -->
<table class="tablegenerale" align="center" border="0">
<tr><td>

<div align=center>
<font size=5>Cette page n'existe pas ou est en construction</font>
<br><br>
<a href="http://www.chess-teaching.com/">Retour � l'accueil</a>
</div>

<!-- fin table generale -->
</td></tr></table>

<?php
include('footer.php');
?>

</body>
</html>
