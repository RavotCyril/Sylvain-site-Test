<table cellpadding=2 width="100%" cellspacing=0 class="piedpage" align="center">
<tr>
<td align='left' style='font-size: 16px;'>
	<u>Contact</u>: <b>contact@chess-teaching.com</b>
</td>
<td align='right' valign='middle' style='font-size: 16px;'>
	<a href="http://www.chess-teaching.com/a_propos.php">� propos</a>
</td>
</tr></table>
