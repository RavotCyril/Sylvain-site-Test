<html><head>
<title>Chess Teaching - Enseignement du Jeu d'Echecs - Contribuer</title>
<?php
include('metas.php');
?>
</head>
<body topmargin="0" leftmargin="0" rightmargin="0">

<?php
include('entete.php');
?>

<!-- Table de la page enti�re en dessous du bandeau -->
<table class="tablegenerale" align="center" border="0">
<tr><td>

<div align=center style="margin-top: 0px;">
<font size=5>Contribuer au projet</font>
</div>

<br><br>
Voici pour vous diff�rentes fa�ons de contribuer � cette plateforme :<br>
<ul>
<li>Faire conna�tre le site (r�seaux sociaux, etc.)</li>
<li>Faire simplement vos remarques et retours, positifs ou n�gatifs</li>
<br>
<li>Vous emparer d'un projet (figurant ou non sur la page d'accueil)</li>
<li>Contribuer � un projet ou une th�matique de mani�re ponctuelle ou durable</li>
<br>
<li>Participer au design du site</li>
<li>Participer au codage du site</li>
<br>
<li>Faire <a href="https://www.paypal.me/SylvainRavot" target="_blank">un don</a></li>
</ul>
<br>
Si vous contribuez vous pourrez si vous le souhaitez avoir votre page personnelle (<a href="http://www.chess-teaching.com/contributeurs/sylvain_ravot.php" target="_blank">comme celle-ci</a>).

<br><br>

</div>

<!-- fin table generale -->
</td></tr></table>

<?php
include('footer.php');
?>

</body>
</html>
